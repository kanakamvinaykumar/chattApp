@extends('layout.mainlayout')
@section('content')
<!-- Page Wrapper -->
<div class="page-wrapper">
			
            <!-- Page Content -->
            <div class="content container-fluid">
            
                <!-- Page Header -->
                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Knowledgebase</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index">Dashboard</a></li>
                                <li class="breadcrumb-item active">Knowledgebase</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /Page Header -->
                
                <div class="row">
                    <div class="col-xl-4 col-md-6 col-sm-6">
                        <div class="topics">
                            <h3 class="topic-title"><a href="#"><i class="fa fa-folder-o"></i> Installation & Activation <span>11</span></a></h3>
                            <ul class="topics-list">
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 col-sm-6">
                        <div class="topics">
                            <h3 class="topic-title"><a href="#"><i class="fa fa-folder-o"></i> Premium Members Features <span>11</span></a></h3>
                            <ul class="topics-list">
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 col-sm-6">
                        <div class="topics">
                            <h3 class="topic-title"><a href="#"><i class="fa fa-folder-o"></i> API Usage & Guide lines <span>11</span></a></h3>
                            <ul class="topics-list">
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 col-sm-6">
                        <div class="topics">
                            <h3 class="topic-title"><a href="#"><i class="fa fa-folder-o"></i> Getting Started <span>11</span></a></h3>
                            <ul class="topics-list">
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 col-sm-6">
                        <div class="topics">
                            <h3 class="topic-title"><a href="#"><i class="fa fa-folder-o"></i> Lorem ipsum dolor <span>11</span></a></h3>
                            <ul class="topics-list">
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 col-sm-6">
                        <div class="topics">
                            <h3 class="topic-title"><a href="#"><i class="fa fa-folder-o"></i> Lorem ipsum dolor <span>11</span></a></h3>
                            <ul class="topics-list">
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 col-sm-6">
                        <div class="topics">
                            <h3 class="topic-title"><a href="#"><i class="fa fa-folder-o"></i> Lorem ipsum dolor <span>11</span></a></h3>
                            <ul class="topics-list">
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 col-sm-6">
                        <div class="topics">
                            <h3 class="topic-title"><a href="#"><i class="fa fa-folder-o"></i> Lorem ipsum dolor <span>11</span></a></h3>
                            <ul class="topics-list">
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 col-sm-6 ">
                        <div class="topics">
                            <h3 class="topic-title"><a href="#"><i class="fa fa-folder-o"></i> Lorem ipsum dolor <span>11</span></a></h3>
                            <ul class="topics-list">
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                                <li><a href="knowledgebase-view"> Sed ut perspiciatis unde omnis? </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
            </div>
            <!-- /Page Content -->
            
        </div>
        <!-- /Page Wrapper -->
@endsection