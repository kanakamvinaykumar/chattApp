<?php return array (
  'blocked-user-search' => 'App\\Http\\Livewire\\BlockedUserSearch',
  'group-search' => 'App\\Http\\Livewire\\GroupSearch',
  'my-contacts-search' => 'App\\Http\\Livewire\\MyContactsSearch',
  'search-group-members-for-create-group' => 'App\\Http\\Livewire\\SearchGroupMembersForCreateGroup',
  'search-group-members-for-edit-group' => 'App\\Http\\Livewire\\SearchGroupMembersForEditGroup',
  'search-users' => 'App\\Http\\Livewire\\SearchUsers',
);