alter table `users` add `language` varchar(191) not null default 'en'
